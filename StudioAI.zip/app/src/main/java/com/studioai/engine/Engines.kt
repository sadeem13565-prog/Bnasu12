package com.studioai.engine

import com.studioai.core.Workspace
import org.json.JSONObject
import java.io.File

interface EngineConnector {
    val id: String
    val label: String
    val note: String
    val canPreview: Boolean
    fun detect(ws: Workspace): Boolean
    fun validate(ws: Workspace): List<String>
    fun previewEntry(ws: Workspace): File? = null
    fun previewBlocker(): String
    fun createStarter(ws: Workspace)
}

object WebEngine : EngineConnector {
    override val id = "web"
    override val label = "ويب (HTML / JS)"
    override val note = "يعمل بالكامل على الهاتف: تعديل + معاينة"
    override val canPreview = true
    override fun detect(ws: Workspace) = File(ws.root, "index.html").isFile
    override fun validate(ws: Workspace): List<String> {
        val idx = File(ws.root, "index.html")
        if (!idx.isFile) return listOf("index.html غير موجود")
        val missing = Regex("""src\s*=\s*["']([^"':]+)["']""").findAll(idx.readText())
            .map { it.groupValues[1] }.filter { !File(ws.root, it).exists() }
        return missing.map { "ملف مذكور في index.html غير موجود: $it" }.toList()
    }
    override fun previewEntry(ws: Workspace) = File(ws.root, "index.html").takeIf { it.isFile }
    override fun previewBlocker() = "لا يوجد index.html"
    override fun createStarter(ws: Workspace) {
        ws.write("index.html", """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Game</title>
<style>html,body{margin:0;background:#111;height:100%}canvas{display:block;margin:auto;background:#1b1b2f}</style></head>
<body><canvas id="c" width="360" height="560"></canvas><script src="game.js"></script></body></html>""")
        ws.write("game.js", """const c=document.getElementById('c'),x=c.getContext('2d');
let p={x:160,y:500,w:40,h:40};
function move(e){const r=c.getBoundingClientRect();const t=e.touches?e.touches[0]:e;p.x=t.clientX-r.left-p.w/2}
c.addEventListener('touchmove',move);c.addEventListener('mousemove',move);
function loop(){x.clearRect(0,0,c.width,c.height);x.fillStyle='#4cc9f0';x.fillRect(p.x,p.y,p.w,p.h);requestAnimationFrame(loop)}
loop();""")
    }
}

object GodotEngine : EngineConnector {
    override val id = "godot"
    override val label = "Godot"
    override val note = "تعديل وفحص الملفات هنا. التشغيل يحتاج تطبيق Godot أو تصدير"
    override val canPreview = false
    override fun detect(ws: Workspace) = File(ws.root, "project.godot").isFile
    override fun validate(ws: Workspace): List<String> {
        val f = File(ws.root, "project.godot")
        if (!f.isFile) return listOf("project.godot غير موجود")
        val m = Regex("""run/main_scene\s*=\s*"res://([^"]+)"""").find(f.readText()) ?: return listOf("لم يُحدد المشهد الرئيسي")
        return if (File(ws.root, m.groupValues[1]).exists()) emptyList() else listOf("المشهد الرئيسي غير موجود: ${m.groupValues[1]}")
    }
    override fun previewBlocker() = "مشاريع Godot تحتاج محرك Godot (تطبيق منفصل) أو تصدير لويب/أندرويد. لا يوجد محرك مدمج في Studio AI"
    override fun createStarter(ws: Workspace) {
        ws.write("project.godot", "config_version=5\n\n[application]\n\nconfig/name=\"StudioGame\"\nrun/main_scene=\"res://main.tscn\"\n")
        ws.write("main.tscn", "[gd_scene format=3]\n\n[node name=\"Main\" type=\"Node2D\"]\n")
    }
}

object UnrealEngine : EngineConnector {
    override val id = "unreal"
    override val label = "Unreal Engine"
    override val note = "تعديل وفحص الملفات فقط. البناء والتشغيل يحتاجان كمبيوتر"
    override val canPreview = false
    override fun detect(ws: Workspace) = ws.root.listFiles()?.any { it.name.endsWith(".uproject") } == true
    override fun validate(ws: Workspace): List<String> {
        val f = ws.root.listFiles()?.firstOrNull { it.name.endsWith(".uproject") } ?: return listOf("ملف .uproject غير موجود")
        return try { JSONObject(f.readText()); emptyList() } catch (e: Exception) { listOf(".uproject ليس JSON صالحاً") }
    }
    override fun previewBlocker() = "Unreal لا يعمل على أندرويد. يلزم كمبيوتر أو خدمة بناء خارجية"
    override fun createStarter(ws: Workspace) {
        ws.write("StudioGame.uproject", """{
  "FileVersion": 3,
  "EngineAssociation": "",
  "Category": "",
  "Description": "Created by Studio AI",
  "Modules": []
}""")
    }
}

object Engines {
    val all: List<EngineConnector> = listOf(WebEngine, GodotEngine, UnrealEngine)
    fun byId(id: String) = all.firstOrNull { it.id == id }
    fun detect(ws: Workspace) = all.firstOrNull { it.detect(ws) }
}
