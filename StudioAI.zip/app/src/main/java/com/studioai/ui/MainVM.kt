package com.studioai.ui

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.studioai.ai.*
import com.studioai.core.*
import com.studioai.data.SecureKeys
import com.studioai.engine.Engines
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainVM(app: Application) : AndroidViewModel(app) {
    private val base = File(app.filesDir, "projects").also { it.mkdirs() }
    private val keys = SecureKeys(app)
    private val prefs = app.getSharedPreferences("settings", 0)

    var screen by mutableStateOf("home")
    var projects by mutableStateOf(listOf<String>())
    var current by mutableStateOf<Project?>(null)
    val log = mutableStateListOf<String>()
    var running by mutableStateOf(false)
    var pausedTask by mutableStateOf<String?>(null)
    var confirmMsg by mutableStateOf<String?>(null)
    private var confirmDef: CompletableDeferred<Boolean>? = null
    var previewFile by mutableStateOf<File?>(null)
    var activeProvider by mutableStateOf(prefs.getString("provider", "gemini")!!)
    val hasKey = mutableStateMapOf<String, Boolean>()
    var settingsMsg by mutableStateOf("")

    init { refresh(); Providers.all.forEach { hasKey[it.id] = keys.has(it.id) } }

    private fun refresh() { projects = base.listFiles()?.filter { it.isDirectory }?.map { it.name }?.sorted() ?: emptyList() }
    private fun say(s: String) { log.add(s) }

    // ---------- projects ----------
    fun createProject(engineId: String) {
        val eng = Engines.byId(engineId) ?: return
        val dir = File(base, "${engineId}-${System.currentTimeMillis() / 1000}")
        val p = Project(dir)
        eng.createStarter(p.ws)
        p.engine = engineId; p.name = "${eng.label} ${projects.size + 1}"
        p.save(); refresh(); open(p.dir.name)
        say("تم إنشاء مشروع ${eng.label} جاهز مع ملفات بداية حقيقية")
    }

    fun open(name: String) {
        val p = Project.open(File(base, name))
        current = p; log.clear()
        pausedTask = p.tasks.lastOrNull { it.status == "PAUSED" }?.id
        say("فُتح: ${p.name} — ${p.ws.tree().size} ملف")
        p.tasks.takeLast(5).forEach { say("سجل: [${it.status}] ${it.request}") }
        screen = "work"
    }

    fun importZip(uri: Uri) = viewModelScope.launch {
        try {
            val p = withContext(Dispatchers.IO) {
                val dir = File(base, "import-${System.currentTimeMillis() / 1000}")
                val p = Project(dir)
                getApplication<Application>().contentResolver.openInputStream(uri)!!.use { ZipUtil.extract(it, p.ws.root) }
                ZipUtil.flattenSingleRoot(p.ws.root)
                getApplication<Application>().contentResolver.openInputStream(uri)!!.use { i -> p.originalZip.outputStream().use { i.copyTo(it) } }
                val eng = Engines.detect(p.ws)
                p.engine = eng?.id ?: "unknown"; p.name = "مستورد ${dir.name.takeLast(4)}"
                p.save(); p
            }
            refresh(); open(p.dir.name)
            val eng = Engines.byId(p.engine)
            say(if (eng == null) "لم أتعرف على نوع المحرك. الملفات مقروءة وقابلة للتعديل لكن بلا فحص خاص"
                else "المحرك المحتمل: ${eng.label}")
            eng?.validate(p.ws)?.forEach { say("تنبيه: $it") }
            say("نسخة أصلية محفوظة. ملفات: ${p.ws.tree().size}")
        } catch (e: ZipSecurityException) { say("رُفض الملف (أمان): ${e.message}") }
        catch (e: ZipCorruptException) { say("الأرشيف تالف: ${e.message}") }
        catch (e: Exception) { say("فشل الاستيراد: ${Redactor.redact(e.message ?: "")}") }
    }

    fun exportTo(uri: Uri) = viewModelScope.launch {
        val p = current ?: return@launch
        try {
            val n = withContext(Dispatchers.IO) {
                val tmp = File(getApplication<Application>().cacheDir, "export.zip")
                val count = tmp.outputStream().use { ZipUtil.pack(p.ws.root, it) }
                if (count == 0) throw IllegalStateException("لا توجد ملفات للتصدير")
                val verified = ZipUtil.verify(tmp)
                getApplication<Application>().contentResolver.openOutputStream(uri)!!.use { o -> tmp.inputStream().use { it.copyTo(o) } }
                tmp.delete(); verified
            }
            say("تم التصدير: $n ملف (تم التحقق من الأرشيف)")
        } catch (e: Exception) { say("فشل التصدير: ${e.message}") }
    }

    fun checkpoint() {
        val p = current ?: return
        p.makeSnapshot("manual-${System.currentTimeMillis()}"); p.save()
        say("تم الحفظ + نقطة استعادة")
    }

    fun undo() {
        val p = current ?: return
        val r = p.undoLast()
        say(if (r == null) "لا توجد مهمة للتراجع عنها" else "تم التراجع عن: $r")
    }

    fun preview() {
        val p = current ?: return
        val eng = Engines.byId(p.engine)
        val f = eng?.takeIf { it.canPreview }?.previewEntry(p.ws)
        if (f != null) previewFile = f else say("المعاينة غير متاحة: ${eng?.previewBlocker() ?: "نوع المشروع غير معروف"}")
    }

    // ---------- tasks ----------
    fun execute(request: String) {
        val p = current ?: return
        if (running || request.isBlank()) return
        val t = TaskRec(id = "t${System.currentTimeMillis()}", request = request.trim())
        p.tasks.add(t)
        run(p, t)
    }

    fun resume() {
        val p = current ?: return
        val t = p.tasks.lastOrNull { it.status == "PAUSED" } ?: return
        if (!running) run(p, t)
    }

    private fun run(p: Project, t: TaskRec) {
        val prov = Providers.get(activeProvider)
        val key = keys.get(prov.id)
        if (key == null) { say("أضف مفتاح ${prov.label} من الإعدادات"); t.status = "PAUSED"; pausedTask = t.id; p.save(); return }
        running = true; pausedTask = null
        say("▶ ${t.request}  (${prov.label})")
        viewModelScope.launch {
            try {
                Agent(p).run(t, prov, key, model(prov.id), { say(it) }) { msg ->
                    val d = CompletableDeferred<Boolean>(); confirmDef = d; confirmMsg = msg; d.await()
                }
                if (t.status == "DONE") {
                    say("✔ اكتملت: ${t.summary}")
                    val diff = p.changesSince(t.id)
                    say("الملفات المتغيرة فعلياً: " + if (diff.isEmpty()) "لا شيء" else diff.joinToString("، "))
                    Engines.byId(p.engine)?.validate(p.ws)?.forEach { say("فحص: $it") }
                } else { say("⏸ ${t.summary}"); pausedTask = t.id }
            } catch (e: QuotaException) { stop(t, "انتهت الحصة/الرصيد لـ ${prov.label}. العمل محفوظ. أضف مفتاحاً آخر أو بدّل المزود ثم اضغط كمّل") }
            catch (e: AuthException) { stop(t, "مفتاح ${prov.label} مرفوض. غيّره من الإعدادات ثم كمّل") }
            catch (e: NetException) { stop(t, "${e.message}. العمل محفوظ، كمّل عند عودة الاتصال") }
            catch (e: Exception) { stop(t, "خطأ: ${Redactor.redact(e.message ?: e.javaClass.simpleName, listOf(key))}") }
            finally { p.save(); running = false }
        }
    }

    private fun stop(t: TaskRec, msg: String) { t.status = "PAUSED"; pausedTask = t.id; say("⏸ $msg") }

    fun answerConfirm(ok: Boolean) { confirmDef?.complete(ok); confirmDef = null; confirmMsg = null }

    // ---------- settings ----------
    fun model(id: String) = prefs.getString("model_$id", null) ?: Providers.get(id).defaultModel
    fun setModel(id: String, m: String) { prefs.edit().putString("model_$id", m.trim()).apply() }
    fun setProvider(id: String) { activeProvider = id; prefs.edit().putString("provider", id).apply() }
    fun saveKey(id: String, k: String) { if (k.isNotBlank()) { keys.set(id, k); hasKey[id] = true; settingsMsg = "تم حفظ المفتاح" } }
    fun deleteKey(id: String) { keys.delete(id); hasKey[id] = false; settingsMsg = "تم حذف المفتاح" }

    fun testConnection(id: String) {
        val k = keys.get(id) ?: run { settingsMsg = "أدخل المفتاح أولاً"; return }
        settingsMsg = "جاري التجربة..."
        viewModelScope.launch {
            settingsMsg = try {
                Providers.get(id).chat(k, model(id), "Reply with OK", listOf(ChatMsg("user", "ping"))); "الاتصال يعمل ✔"
            } catch (e: Exception) { Redactor.redact(e.message ?: "فشل", listOf(k)) }
        }
    }
}
