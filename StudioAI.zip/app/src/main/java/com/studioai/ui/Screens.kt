package com.studioai.ui

import android.webkit.WebView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.studioai.ai.Providers
import com.studioai.engine.Engines

@Composable
fun App(vm: MainVM) {
    val importL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::importZip) }
    val exportL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { it?.let(vm::exportTo) }
    BackHandler(vm.screen != "home") { vm.screen = if (vm.screen == "settings" && vm.current != null) "work" else "home" }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().systemBarsPadding().padding(12.dp)) {
                when (vm.screen) {
                    "settings" -> Settings(vm)
                    "work" -> Work(vm, { exportL.launch("${vm.current?.name ?: "project"}.zip") })
                    else -> Home(vm) { importL.launch(arrayOf("application/zip", "application/octet-stream")) }
                }
            }
        }
        vm.confirmMsg?.let { m ->
            AlertDialog(onDismissRequest = { vm.answerConfirm(false) },
                title = { Text("موافقة مطلوبة") }, text = { Text(m) },
                confirmButton = { TextButton({ vm.answerConfirm(true) }) { Text("موافق") } },
                dismissButton = { TextButton({ vm.answerConfirm(false) }) { Text("رفض") } })
        }
        vm.previewFile?.let { f ->
            Dialog({ vm.previewFile = null }, DialogProperties(usePlatformDefaultWidth = false)) {
                Surface(Modifier.fillMaxSize()) {
                    Column {
                        TextButton({ vm.previewFile = null }) { Text("إغلاق المعاينة") }
                        AndroidView({ ctx ->
                            WebView(ctx).apply {
                                settings.javaScriptEnabled = true
                                settings.allowFileAccess = true
                                loadUrl("file://" + f.absolutePath)
                            }
                        }, Modifier.fillMaxSize())
                    }
                }
            }
        }
    }
}

@Composable
fun Home(vm: MainVM, onImport: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("Studio AI", style = MaterialTheme.typography.headlineMedium)
        TextButton({ vm.screen = "settings" }) { Text("الإعدادات ⚙") }
    }
    Text("اختر المحرك", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
    Engines.all.forEach { e ->
        Button({ vm.createProject(e.id) }, Modifier.fillMaxWidth().padding(top = 8.dp)) { Text(e.label) }
        Text(e.note, style = MaterialTheme.typography.bodySmall)
    }
    OutlinedButton(onImport, Modifier.fillMaxWidth().padding(top = 16.dp)) { Text("فتح مشروع موجود (ZIP)") }
    if (vm.projects.isNotEmpty()) {
        Text("مشاريعك", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 16.dp))
        LazyColumn { items(vm.projects) { n -> Text(n, Modifier.fillMaxWidth().clickable { vm.open(n) }.padding(12.dp)) } }
    }
}

@Composable
fun Work(vm: MainVM, onExport: () -> Unit) {
    val p = vm.current ?: return
    var cmd by remember { mutableStateOf("") }
    val state = when { vm.running -> "قيد التنفيذ"; vm.pausedTask != null -> "متوقف"; else -> "جاهز" }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Column {
            Text(p.name, style = MaterialTheme.typography.titleMedium)
            Text("${Engines.byId(p.engine)?.label ?: "غير معروف"} • $state • ${Providers.get(vm.activeProvider).label}",
                style = MaterialTheme.typography.bodySmall)
        }
        Row {
            TextButton({ vm.screen = "home" }) { Text("مشاريع") }
            TextButton({ vm.screen = "settings" }) { Text("⚙") }
        }
    }
    LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp), reverseLayout = true) {
        items(vm.log.reversed()) { Text(it, Modifier.padding(vertical = 3.dp), style = MaterialTheme.typography.bodyMedium) }
    }
    if (vm.pausedTask != null && !vm.running) {
        Card(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
            Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("المهمة متوقفة. العمل محفوظ", Modifier.weight(1f))
                Button({ vm.resume() }) { Text("كمّل") }
            }
        }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        OutlinedButton({ vm.checkpoint() }, Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("حفظ") }
        OutlinedButton({ vm.undo() }, Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("تراجع") }
        OutlinedButton({ vm.preview() }, Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("تشغيل") }
        OutlinedButton(onExport, Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("تصدير") }
    }
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedTextField(cmd, { cmd = it }, Modifier.weight(1f), placeholder = { Text("اكتب ما تريد تعديله") }, maxLines = 4)
        Button({ vm.execute(cmd); cmd = "" }, enabled = !vm.running && cmd.isNotBlank()) { Text("تنفيذ") }
    }
}

@Composable
fun Settings(vm: MainVM) {
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Text("الإعدادات", style = MaterialTheme.typography.headlineSmall)
        Text("المفتاح يُحفظ مشفراً على جهازك فقط. اختر المزود النشط، وبدّل بينهم متى شئت وكمّل نفس المهمة.",
            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp))
        Providers.all.forEach { pr ->
            var key by remember { mutableStateOf("") }
            var model by remember { mutableStateOf(vm.model(pr.id)) }
            Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Row {
                        RadioButton(vm.activeProvider == pr.id, { vm.setProvider(pr.id) })
                        Column {
                            Text(pr.label, style = MaterialTheme.typography.titleSmall)
                            Text(if (vm.hasKey[pr.id] == true) "مفتاح محفوظ ✔" else "لا يوجد مفتاح", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    OutlinedTextField(model, { model = it; vm.setModel(pr.id, it) }, Modifier.fillMaxWidth(), label = { Text("معرّف النموذج (قابل للتعديل)") }, singleLine = true)
                    OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth().padding(top = 6.dp), label = { Text("مفتاح API") },
                        visualTransformation = PasswordVisualTransformation(), singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Button({ vm.saveKey(pr.id, key); key = "" }, enabled = key.isNotBlank()) { Text("حفظ") }
                        OutlinedButton({ vm.testConnection(pr.id) }) { Text("تجربة") }
                        TextButton({ vm.deleteKey(pr.id) }) { Text("حذف") }
                    }
                }
            }
        }
        if (vm.settingsMsg.isNotEmpty()) Text(vm.settingsMsg, Modifier.padding(8.dp))
    }
}
