package com.studioai.core

import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class ZipSecurityException(msg: String) : Exception(msg)
class ZipCorruptException(msg: String) : Exception(msg)

object ZipUtil {
    fun extract(input: InputStream, dest: File, maxEntries: Int = 20000, maxTotal: Long = 1L shl 29) {
        val root = dest.canonicalFile
        root.mkdirs()
        var n = 0
        var total = 0L
        try {
            ZipInputStream(input).use { zis ->
                var e = zis.nextEntry
                while (e != null) {
                    n++
                    if (n > maxEntries) throw ZipSecurityException("too many entries")
                    val out = File(root, e.name).canonicalFile
                    if (!(out.path == root.path || out.path.startsWith(root.path + File.separator)))
                        throw ZipSecurityException("path escapes project: ${e.name}")
                    if (e.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { o ->
                            val buf = ByteArray(8192)
                            while (true) {
                                val r = zis.read(buf)
                                if (r < 0) break
                                total += r
                                if (total > maxTotal) throw ZipSecurityException("archive too large")
                                o.write(buf, 0, r)
                            }
                        }
                    }
                    e = zis.nextEntry
                }
            }
        } catch (ex: ZipSecurityException) {
            throw ex
        } catch (ex: java.io.IOException) {
            throw ZipCorruptException(ex.message ?: "corrupt zip")
        }
        if (n == 0) throw ZipCorruptException("empty or invalid zip")
    }

    /** If the archive has a single top-level folder, move its contents up. */
    fun flattenSingleRoot(dir: File) {
        val kids = dir.listFiles() ?: return
        if (kids.size == 1 && kids[0].isDirectory) {
            val tmp = File(dir.parentFile, dir.name + "_tmp")
            kids[0].renameTo(tmp)
            dir.deleteRecursively()
            tmp.renameTo(dir)
        }
    }

    fun pack(src: File, out: OutputStream, skip: Set<String> = setOf(".studio")): Int {
        var count = 0
        val base = src.canonicalFile
        ZipOutputStream(out).use { zos ->
            base.walkTopDown().filter { it.isFile }.forEach { f ->
                val rel = f.relativeTo(base).path.replace('\\', '/')
                if (rel.split('/').any { it in skip }) return@forEach
                zos.putNextEntry(ZipEntry(rel))
                f.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
                count++
            }
        }
        return count
    }

    /** Reads every entry fully; returns the entry count, throws if corrupt. */
    fun verify(zip: File): Int {
        try {
            ZipFile(zip).use { z ->
                var n = 0
                val buf = ByteArray(8192)
                for (e in z.entries()) {
                    z.getInputStream(e).use { s -> while (s.read(buf) >= 0) { } }
                    n++
                }
                return n
            }
        } catch (ex: java.io.IOException) {
            throw ZipCorruptException(ex.message ?: "corrupt zip")
        }
    }
}
