package com.studioai.core

import java.io.File

class Workspace(rootDir: File) {
    val root: File = rootDir.also { it.mkdirs() }.canonicalFile

    fun resolve(rel: String): File {
        val f = File(root, rel).canonicalFile
        require(f.path == root.path || f.path.startsWith(root.path + File.separator)) { "path outside project: $rel" }
        return f
    }

    fun tree(max: Int = 500): List<String> =
        root.walkTopDown().filter { it.isFile }
            .map { it.relativeTo(root).path.replace('\\', '/') }.take(max).toList()

    fun read(rel: String, limit: Int = 20000): String {
        val f = resolve(rel)
        require(f.isFile) { "not a file: $rel" }
        val t = f.readText()
        if (t.contains('\u0000')) return "[binary file]"
        return if (t.length > limit) t.take(limit) + "\n[truncated]" else t
    }

    fun write(rel: String, content: String) {
        val f = resolve(rel)
        f.parentFile?.mkdirs()
        f.writeText(content)
    }

    fun delete(rel: String): Boolean = resolve(rel).let { it.isFile && it.delete() }

    fun rename(from: String, to: String) {
        val a = resolve(from)
        val b = resolve(to)
        require(a.exists()) { "missing: $from" }
        b.parentFile?.mkdirs()
        require(a.renameTo(b)) { "rename failed" }
    }

    fun search(q: String, max: Int = 50): List<String> {
        val out = mutableListOf<String>()
        for (rel in tree()) {
            val f = resolve(rel)
            if (f.length() > 500_000) continue
            val lines = try { f.readLines() } catch (e: Exception) { continue }
            lines.forEachIndexed { i, l ->
                if (out.size < max && l.contains(q, ignoreCase = true)) out.add("$rel:${i + 1}: ${l.trim().take(120)}")
            }
        }
        return out
    }

    fun snapshot(dest: File) {
        dest.deleteRecursively()
        dest.mkdirs()
        root.copyRecursively(dest, overwrite = true)
    }

    fun restore(src: File) {
        root.listFiles()?.forEach { it.deleteRecursively() }
        src.copyRecursively(root, overwrite = true)
    }

    /** Files added/modified/removed compared with a snapshot. */
    fun diff(snap: File): List<String> {
        val s = snap.canonicalFile
        fun map(d: File) = d.walkTopDown().filter { it.isFile }.associateBy { it.relativeTo(d).path.replace('\\', '/') }
        val a = map(s)
        val b = map(root)
        val res = mutableListOf<String>()
        b.forEach { (k, f) ->
            val o = a[k]
            if (o == null) res.add("+ $k") else if (!o.readBytes().contentEquals(f.readBytes())) res.add("~ $k")
        }
        a.keys.filter { it !in b }.forEach { res.add("- $it") }
        return res.sorted()
    }
}
