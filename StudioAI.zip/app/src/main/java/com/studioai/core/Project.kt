package com.studioai.core

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class TaskRec(
    val id: String,
    val request: String,
    var status: String = "RUNNING",
    var summary: String = "",
    val changed: MutableList<String> = mutableListOf(),
    val steps: MutableList<String> = mutableListOf(),
    var provider: String = ""
)

class Project(val dir: File) {
    val ws = Workspace(File(dir, "files"))
    private val meta = File(dir, "meta").also { it.mkdirs() }
    private val stateFile = File(meta, "state.json")
    val snapshotsDir get() = File(meta, "snapshots")
    val originalZip get() = File(meta, "original.zip")

    var name: String = dir.name
    var engine: String = "unknown"
    var description: String = ""
    val tasks = mutableListOf<TaskRec>()

    fun save() {
        val o = JSONObject()
        o.put("name", name)
        o.put("engine", engine)
        o.put("description", description)
        val arr = JSONArray()
        tasks.forEach { t ->
            arr.put(JSONObject().apply {
                put("id", t.id); put("request", t.request); put("status", t.status)
                put("summary", t.summary); put("provider", t.provider)
                put("changed", JSONArray(t.changed)); put("steps", JSONArray(t.steps))
            })
        }
        o.put("tasks", arr)
        val tmp = File(meta, "state.json.tmp")
        tmp.writeText(o.toString(2))
        tmp.renameTo(stateFile)
    }

    fun load() {
        if (!stateFile.exists()) return
        val o = JSONObject(stateFile.readText())
        name = o.optString("name", name)
        engine = o.optString("engine", engine)
        description = o.optString("description", "")
        tasks.clear()
        val arr = o.optJSONArray("tasks") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val t = arr.getJSONObject(i)
            fun list(k: String): MutableList<String> {
                val a = t.optJSONArray(k) ?: return mutableListOf()
                return (0 until a.length()).map { a.getString(it) }.toMutableList()
            }
            tasks.add(TaskRec(t.getString("id"), t.getString("request"), t.optString("status"),
                t.optString("summary"), list("changed"), list("steps"), t.optString("provider")))
        }
    }

    fun makeSnapshot(id: String) = ws.snapshot(File(snapshotsDir, id))

    fun undoLast(): String? {
        val t = tasks.lastOrNull { File(snapshotsDir, it.id).exists() && it.status != "REVERTED" } ?: return null
        ws.restore(File(snapshotsDir, t.id))
        t.status = "REVERTED"
        save()
        return t.request
    }

    fun changesSince(id: String): List<String> = ws.diff(File(snapshotsDir, id))

    companion object {
        fun open(dir: File) = Project(dir).also { it.load() }
    }
}
