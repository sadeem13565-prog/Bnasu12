package com.studioai.core

object Redactor {
    private val patterns = listOf(
        Regex("sk-[A-Za-z0-9_\\-]{16,}"),
        Regex("AIza[0-9A-Za-z_\\-]{20,}")
    )
    fun redact(text: String, secrets: Collection<String> = emptyList()): String {
        var r = text
        secrets.filter { it.length >= 6 }.forEach { r = r.replace(it, "***") }
        patterns.forEach { r = it.replace(r, "***") }
        return r
    }
}
