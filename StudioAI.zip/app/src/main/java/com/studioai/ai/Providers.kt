package com.studioai.ai

import com.studioai.core.Redactor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class QuotaException(msg: String) : Exception(msg)
class AuthException(msg: String) : Exception(msg)
class NetException(msg: String) : Exception(msg)

data class ChatMsg(val role: String, val text: String) // role: "user" | "assistant"

interface AiProvider {
    val id: String
    val label: String
    /** Editable in Settings: model IDs change over time, check the provider's docs. */
    val defaultModel: String
    suspend fun chat(apiKey: String, model: String, system: String, messages: List<ChatMsg>): String
}

internal object Http {
    fun post(url: String, headers: Map<String, String>, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 20000
            c.readTimeout = 120000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toByteArray()) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            if (code in 200..299) return text
            val low = text.lowercase()
            val short = Redactor.redact(text.take(200), headers.values)
            throw when {
                code == 429 || code == 402 || "credit balance" in low || "insufficient_quota" in low ||
                    "resource_exhausted" in low || "billing" in low -> QuotaException("الحصة أو الرصيد انتهى (HTTP $code): $short")
                code == 401 || code == 403 -> AuthException("المفتاح مرفوض (HTTP $code)")
                else -> NetException("خطأ من الخادم (HTTP $code): $short")
            }
        } catch (e: java.io.IOException) {
            throw NetException("تعذر الاتصال بالإنترنت")
        } finally {
            c.disconnect()
        }
    }
}

object GeminiProvider : AiProvider {
    override val id = "gemini"
    override val label = "Google Gemini"
    override val defaultModel = "gemini-2.5-flash"
    override suspend fun chat(apiKey: String, model: String, system: String, messages: List<ChatMsg>): String =
        withContext(Dispatchers.IO) {
            val contents = JSONArray()
            messages.forEach {
                contents.put(JSONObject().put("role", if (it.role == "assistant") "model" else "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", it.text))))
            }
            val body = JSONObject().put("contents", contents)
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            val r = JSONObject(Http.post(
                "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
                mapOf("x-goog-api-key" to apiKey), body.toString()))
            val parts = r.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
            (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }
        }
}

object ClaudeProvider : AiProvider {
    override val id = "claude"
    override val label = "Anthropic Claude"
    override val defaultModel = "claude-sonnet-5-5"
    override suspend fun chat(apiKey: String, model: String, system: String, messages: List<ChatMsg>): String =
        withContext(Dispatchers.IO) {
            val msgs = JSONArray()
            messages.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.text)) }
            val body = JSONObject().put("model", model).put("max_tokens", 8000).put("system", system).put("messages", msgs)
            val r = JSONObject(Http.post("https://api.anthropic.com/v1/messages",
                mapOf("x-api-key" to apiKey, "anthropic-version" to "2023-06-01"), body.toString()))
            val c = r.getJSONArray("content")
            (0 until c.length()).joinToString("") { c.getJSONObject(it).optString("text") }
        }
}

object OpenAiProvider : AiProvider {
    override val id = "openai"
    override val label = "OpenAI"
    override val defaultModel = "gpt-5"
    override suspend fun chat(apiKey: String, model: String, system: String, messages: List<ChatMsg>): String =
        withContext(Dispatchers.IO) {
            val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
            messages.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.text)) }
            val body = JSONObject().put("model", model).put("messages", msgs)
            val r = JSONObject(Http.post("https://api.openai.com/v1/chat/completions",
                mapOf("Authorization" to "Bearer $apiKey"), body.toString()))
            r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content")
        }
}

object Providers {
    val all: List<AiProvider> = listOf(GeminiProvider, ClaudeProvider, OpenAiProvider)
    fun get(id: String): AiProvider = all.first { it.id == id }
}
