package com.studioai.ai

import com.studioai.core.Project
import com.studioai.core.TaskRec
import kotlinx.coroutines.CancellationException
import org.json.JSONObject

class Agent(private val project: Project) {

    suspend fun run(
        task: TaskRec, provider: AiProvider, key: String, model: String,
        onStatus: (String) -> Unit, confirm: suspend (String) -> Boolean
    ) {
        val ws = project.ws
        task.provider = provider.id
        if (!java.io.File(project.snapshotsDir, task.id).exists()) {
            onStatus("حفظ نقطة استعادة قبل التعديل")
            project.makeSnapshot(task.id)
        }
        val resumed = task.steps.isNotEmpty()
        val intro = buildString {
            append("TASK: ${task.request}\nENGINE: ${project.engine}\nFILES:\n")
            append(ws.tree().joinToString("\n"))
            if (resumed) {
                append("\n\nTHIS TASK WAS STARTED BY A PREVIOUS MODEL. STEPS ALREADY DONE (files are already changed on disk):\n")
                append(task.steps.joinToString("\n"))
                append("\nContinue from here; do not redo finished work.")
            }
        }
        val msgs = mutableListOf(ChatMsg("user", intro))
        task.status = "RUNNING"
        project.save()

        for (i in 1..MAX_STEPS) {
            onStatus("بانتظار رد ${provider.label}")
            val reply = provider.chat(key, model, SYSTEM, msgs)
            msgs.add(ChatMsg("assistant", reply))
            val call = parse(reply)
            if (call == null) {
                msgs.add(ChatMsg("user", "RESULT: invalid. Reply with exactly one JSON object."))
                continue
            }
            val tool = call.optString("tool")
            if (tool == "finish") {
                task.summary = call.optString("summary")
                task.status = "DONE"
                project.save()
                return
            }
            val result = exec(tool, call, task, onStatus, confirm)
            task.steps.add("$tool ${call.optString("path", call.optString("query", call.optString("from")))}".trim())
            project.save()
            msgs.add(ChatMsg("user", "RESULT:\n$result"))
        }
        task.status = "PAUSED"
        task.summary = "وصلت لحد الخطوات (${MAX_STEPS}) — اضغط كمّل للمتابعة"
        project.save()
    }

    private suspend fun exec(
        tool: String, c: JSONObject, task: TaskRec,
        onStatus: (String) -> Unit, confirm: suspend (String) -> Boolean
    ): String {
        val ws = project.ws
        return try {
            when (tool) {
                "list_files" -> { onStatus("فحص الملفات"); ws.tree().joinToString("\n") }
                "read_file" -> { val p = c.getString("path"); onStatus("قراءة $p (يُرسل للنموذج)"); ws.read(p) }
                "search" -> { val q = c.getString("query"); onStatus("بحث: $q"); ws.search(q).joinToString("\n").ifEmpty { "no matches" } }
                "write_file" -> {
                    val p = c.getString("path"); onStatus("تعديل $p")
                    ws.write(p, c.getString("content"))
                    if (p !in task.changed) task.changed.add(p)
                    "OK"
                }
                "rename_file" -> {
                    val a = c.getString("from"); val b = c.getString("to"); onStatus("إعادة تسمية $a")
                    ws.rename(a, b); task.changed.add("$a -> $b"); "OK"
                }
                "delete_file" -> {
                    val p = c.getString("path")
                    if (!confirm("يريد النموذج حذف الملف:\n$p")) "DENIED by user"
                    else { onStatus("حذف $p"); if (ws.delete(p)) { task.changed.add("- $p"); "OK" } else "ERROR: not a file" }
                }
                else -> "ERROR: unknown tool '$tool'"
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            "ERROR: ${e.message}"
        }
    }

    private fun parse(reply: String): JSONObject? {
        val s = reply.indexOf('{'); val e = reply.lastIndexOf('}')
        if (s < 0 || e <= s) return null
        return try { JSONObject(reply.substring(s, e + 1)) } catch (ex: Exception) { null }
    }

    companion object {
        const val MAX_STEPS = 25
        val SYSTEM = """
You are a coding agent inside a game-development app. You act ONLY by replying with exactly ONE JSON object per message, no other text.
Tools:
{"tool":"list_files"}
{"tool":"read_file","path":"rel/path"}
{"tool":"search","query":"text"}
{"tool":"write_file","path":"rel/path","content":"FULL file content"}
{"tool":"rename_file","from":"a","to":"b"}
{"tool":"delete_file","path":"rel/path"}
{"tool":"finish","summary":"short summary in Arabic of what you really changed"}
Rules: paths are relative to the project root. Read a file before changing it. Keep existing systems working. write_file replaces the whole file. Only claim changes you made with write_file. Call finish when done.
""".trim()
    }
}
