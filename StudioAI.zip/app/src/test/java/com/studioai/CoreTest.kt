package com.studioai

import com.studioai.core.*
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class CoreTest {
    @get:Rule val tmp = TemporaryFolder()

    private fun zip(vararg e: Pair<String, String>): ByteArray {
        val b = ByteArrayOutputStream()
        ZipOutputStream(b).use { z -> e.forEach { (n, c) -> z.putNextEntry(ZipEntry(n)); z.write(c.toByteArray()); z.closeEntry() } }
        return b.toByteArray()
    }

    @Test fun importZipWorks() {
        val d = tmp.newFolder("p")
        ZipUtil.extract(ByteArrayInputStream(zip("a/b.txt" to "hi")), d)
        assertEquals("hi", java.io.File(d, "a/b.txt").readText())
    }

    @Test fun zipSlipBlocked() {
        val d = tmp.newFolder("p")
        try { ZipUtil.extract(ByteArrayInputStream(zip("../evil.txt" to "x")), d); fail() } catch (e: ZipSecurityException) { }
        assertFalse(java.io.File(d.parentFile, "evil.txt").exists())
    }

    @Test fun corruptZipRejected() {
        try { ZipUtil.extract(ByteArrayInputStream("not a zip".toByteArray()), tmp.newFolder("p")); fail() } catch (e: ZipCorruptException) { }
    }

    @Test fun exportAndVerify() {
        val ws = Workspace(tmp.newFolder("w"))
        ws.write("src/a.txt", "1"); ws.write("b.txt", "2")
        val out = tmp.newFile("o.zip")
        assertEquals(2, out.outputStream().use { ZipUtil.pack(ws.root, it) })
        assertEquals(2, ZipUtil.verify(out))
    }

    @Test fun workspaceBlocksEscape() {
        val ws = Workspace(tmp.newFolder("w"))
        try { ws.write("../x.txt", "x"); fail() } catch (e: IllegalArgumentException) { }
    }

    @Test fun snapshotAndRestore() {
        val p = Project(tmp.newFolder("proj"))
        p.ws.write("a.txt", "old")
        p.tasks.add(TaskRec("t1", "edit"))
        p.makeSnapshot("t1")
        p.ws.write("a.txt", "new"); p.ws.write("n.txt", "x")
        val ch = p.changesSince("t1")
        assertTrue("+ n.txt" in ch && "~ a.txt" in ch)
        assertEquals("edit", p.undoLast())
        assertEquals("old", p.ws.read("a.txt"))
        assertFalse(java.io.File(p.ws.root, "n.txt").exists())
    }

    @Test fun stateAndTaskLogPersist() {
        val dir = tmp.newFolder("proj")
        val p = Project(dir)
        p.engine = "web"; p.tasks.add(TaskRec("t1", "req", "PAUSED", "s", mutableListOf("a"), mutableListOf("write_file a"), "gemini"))
        p.save()
        val q = Project.open(dir)
        assertEquals("web", q.engine)
        assertEquals("PAUSED", q.tasks[0].status)
        assertEquals(listOf("write_file a"), q.tasks[0].steps)
    }

    @Test fun keysRedacted() {
        val s = Redactor.redact("error key=AIzaSyA1234567890abcdefghij and sk-ant-abcdefghijklmnop1234 and mykey123", listOf("mykey123"))
        assertFalse(s.contains("AIza")); assertFalse(s.contains("sk-ant")); assertFalse(s.contains("mykey123"))
    }
}
